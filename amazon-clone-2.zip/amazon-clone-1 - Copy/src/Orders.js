import React, { useEffect, useState } from "react";
import { db } from "./firebase";
import "./Orders.css";
import { useStateValue } from "./StateProvider";
import Order from "./Order";

function Orders() {
  const [{ basket, user }, dispatch] = useStateValue();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true); // Add loading state

  useEffect(() => {
    if (user) {
      const unsubscribe = db
        .collection("users")
        .doc(user?.uid)
        .collection("orders")
        .orderBy("created", "desc")
        .onSnapshot(
          (snapshot) => {
            setOrders(
              snapshot.docs.map((doc) => ({
                id: doc.id,
                data: doc.data(),
              }))
            );
            setLoading(false); // Set loading to false when data is loaded
          },
          (error) => {
            console.error("Error fetching orders: ", error);
            setLoading(false); // Set loading to false on error too
          }
        );

      return () => unsubscribe(); // Unsubscribe from snapshot listener
    } else {
      setOrders([]);
      setLoading(false); // Set loading to false if no user is logged in
    }
  }, [user]);

  if (loading) {
    return <div>Loading...</div>; // Display a loading indicator while fetching data
  }

  return (
    <div className="orders">
      <h1>Your Orders</h1>
      <div className="orders__order">
        {orders.length === 0 ? (
          <p>No orders found</p>
        ) : (
          orders.map((order) => <Order key={order.id} order={order} />)
        )}
      </div>
    </div>
  );
}

export default Orders;
