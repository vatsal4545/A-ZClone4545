// import firebase from "firebase";
// import * as firebase from "firebase/app";
// For Firebase JS SDK v7.20.0 and later, measurementId is optional

import firebase from "firebase/compat/app";
import "firebase/compat/auth";
import "firebase/compat/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAXC0WYXMYloYSWQt7cwQnhS6sUgBOtjxU",
  authDomain: "store-3f6b1.firebaseapp.com",
  projectId: "store-3f6b1",
  storageBucket: "store-3f6b1.appspot.com",
  messagingSenderId: "161657736334",
  appId: "1:161657736334:web:cba56da5c631942b030ddf",
  measurementId: "G-JSBPYKZF1B",
};

const firebaseApp = firebase.initializeApp(firebaseConfig);

const db = firebaseApp.firestore();
const auth = firebase.auth();

export { db, auth };
