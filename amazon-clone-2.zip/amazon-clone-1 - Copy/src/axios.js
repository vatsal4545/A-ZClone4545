import axios from "axios";

const instance = axios.create({
  baseURL: "https://us-central1-store-3f6b1.cloudfunctions.net/api",
});
export default instance;
//https://us-central1-store-3f6b1.cloudfunctions.net/api

//http://127.0.0.1:5001/store-3f6b1/us-central1/api
